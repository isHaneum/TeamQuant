# TeamQuant 개인 PC 연결

이 패키지에는 금융 키와 개인 자산이 없습니다. 각 사용자의 PC에서 본인 API 키로만 연결합니다. 서버 회원 계정과 PC 간 동기화는 지원하지 않습니다.

1. Node.js 22 이상을 공식 https://nodejs.org 에서 설치합니다. 별도 npm 의존성 설치는 필요하지 않습니다.
2. 압축을 푼 폴더에 `.env.local` 파일을 만듭니다. 본인의 토스 API 키 파일을 별도 경로에 저장한 뒤 다음 한 줄을 작성합니다.

   TOSS_KEY_FILE=C:/본인경로/toss.key

3. `toss.key`는 두 줄 형식입니다. 실제 값은 공유하지 않습니다.

   client_id=본인ClientID
   client_secret=본인ClientSecret

4. 금융사 개발자센터에서 조회 권한과 현재 PC의 공인 IP 허용 여부를 확인합니다. 토스 발급 키만 사용합니다. 한국투자 키는 토스 자산을 조회하지 못합니다.
5. Windows는 `start-personal-server.cmd`를 실행합니다. 다른 OS는 해당 폴더에서 `node dev-server.mjs`를 실행합니다. 서버는 127.0.0.1:8766에만 연결됩니다.
6. http://127.0.0.1:8766 에서 프로필을 열고 ‘내 실제 자산 → Vercel 연결코드 발급’을 선택합니다.
7. 같은 PC의 https://teamquant.vercel.app 에서 프로필을 열고 ‘내 실제 자산’에 코드를 입력합니다. 브라우저의 로컬 네트워크 접근 요청은 직접 확인하여 허용합니다.
8. ‘지금 점검 → 보유 자산 전략 검증 → 내 자산으로 모의 운용’으로 진행합니다. 먼저 Vercel Strategy Lab에서 원칙을 확인·승인해야 합니다. PC와 Vercel의 전략 저장소는 서로 다릅니다.

코드는 2분·1회 사용, 연결은 1시간입니다. 화면을 열어두면 5분 간격으로 갱신합니다. 새로고침 시 재연결합니다. 보유 주식의 조회 성공·실패 이력은 PC 사용자 데이터 폴더에 기록됩니다. 표시 중인 자산·복사 모의 장부는 탭 메모리에 있으며 필요한 모의 결과는 JSON으로 저장합니다. 화면 삭제·새로고침은 PC 이력 파일을 지우지 않습니다. 실제 주문은 실행하지 않습니다. 같은 PC의 서버는 설정된 API 소유자의 계좌 하나를 제공합니다.

계좌 없이도 Vercel의 ‘3개월 비교’에서 주식·ETF의 가격 자료로 원칙 성과를 검증하고 가상 현금으로 모의 운용할 수 있습니다. 일반 펀드는 date,nav CSV에 의한 연구용 검증만 지원합니다. 매매·환매 기간과 실제 체결을 재현하지 않습니다.

개인 키를 GitHub, Vercel, Notion에 올리지 않습니다. 이 패키지를 다시 공유할 때 `.env.local`, 키 파일, 내보낸 자산 JSON을 제외하십시오.

## 자산 이력 저장(Task A)
기본 위치: Windows `%LOCALAPPDATA%/TeamQuant/portfolio-history`, Linux `$XDG_DATA_HOME/TeamQuant/portfolio-history` 또는 `~/.local/share/TeamQuant/portfolio-history`. `.env.local`의 `TEAMQUANT_HISTORY_DIR`로 변경할 수 있으나 프로젝트 내부 경로는 허용하지 않습니다. 일반 JSON 파일이며 암호화 저장은 아닙니다. 보유 주식·수량·가격·환율·조회 시각을 기록하며, 계좌 식별은 로컬 HMAC을 사용합니다. API 키와 계좌번호 원문은 기록하지 않습니다. 현금·입출금·실현손익·TWR·XIRR·월별 수익률은 미구현입니다. 로컬 이력 조회 UI와 삭제 UI는 후속 작업입니다.
