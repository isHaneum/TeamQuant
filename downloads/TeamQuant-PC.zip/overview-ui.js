import {performanceChart,wireCharts} from '/lib/performance-view.js';
import {stockName,resolveStockInput} from '/lib/instruments.js';
import {portfolioMetrics,evaluatePrinciples,simulateContributions,rebalanceOptions} from '/lib/portfolio.js';
import {briefingQuery,relevantArticles} from '/lib/briefing.js';
const $=s=>document.querySelector(s),money=v=>v===null?'—':Math.round(v).toLocaleString('ko-KR')+'원';
const pct=v=>v===null?'—':(v>0?'+':'')+v.toFixed(2)+'%',esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const key=()=>sessionStorage.getItem('teamQuantSession')?'teamQuant:user:'+sessionStorage.getItem('teamQuantSession'):null;
const state=()=>{try{return JSON.parse(localStorage.getItem(key())||'{}');}catch{return {};}};
let liveAccount=null;
const get=()=>{const o={schemaVersion:1,mode:'paper',quotes:{},newsCache:{},principleVersions:[],reviews:[],simulationRuns:[],...state().overview};if(o.mode==='account'&&(!liveAccount||liveAccount.owner!==key()))o.mode='paper';return o;};
function save(change){const k=key();if(!k)return;const s=state();s.overview={...get(),...change};localStorage.setItem(k,JSON.stringify(s));}
const navigate=page=>$(`[data-view="${page}"]`)?.click();
const DEMO={cash:2800000,positions:[{symbol:'005930.KS',name:'삼성전자',quantity:50,avgCost:70000},{symbol:'000660.KS',name:'SK하이닉스',quantity:10,avgCost:180000},{symbol:'035420.KS',name:'NAVER',quantity:10,avgCost:200000}]};
const demoQuotes={'005930.KS':{price:72000,prevClose:73000},'000660.KS':{price:190000,prevClose:184000},'035420.KS':{price:210000,prevClose:212000}};
function portfolio(){const s=state(),o=get();if(o.mode==='account')return liveAccount.portfolio;if(o.mode==='demo')return DEMO;if(o.mode==='manual')return o.manualPortfolio||{cash:0,positions:[]};return {cash:s.paper?.cash??10000000,positions:Object.values(s.paper?.holdings||{}).map(h=>({symbol:h.symbol,name:stockName(h.symbol),quantity:h.qty,avgCost:h.avgPrice}))};}
function metrics(){const o=get(),p=portfolio(),q=o.mode==='account'?liveAccount.quotes:o.mode==='demo'?Object.fromEntries(Object.entries(demoQuotes).map(([s,x])=>[s,{...x,asOf:'합성 DEMO',source:'예시 가격'}])):{...o.quotes};if(o.mode==='paper')for(const h of Object.values(state().paper?.holdings||{}))if(!q[h.symbol])q[h.symbol]={price:h.lastPrice,prevClose:null,asOf:'모의 거래·검증 시점 가격',source:'기존 모의 잔고'};return portfolioMetrics(p,q);}

// Keep the original home DOM as an integration adapter for the existing modules.
for(const node of [...$('#home').children])node.classList.add('legacy-home');
const root=document.createElement('div');root.id='overview';root.innerHTML=`
  <div class="page-head"><div><p class="eyebrow">PORTFOLIO OVERVIEW</p><h1>내 자산 한눈에</h1><p id="ov-source"></p></div><div class="ov-actions"><select id="ov-mode" aria-label="자산 보기"><option value="paper">내 모의 자산</option><option value="manual">직접 입력한 자산</option><option value="demo">DEMO 살펴보기</option></select><button id="ov-refresh" class="secondary">시세 새로고침</button></div></div>
  <p id="ov-status" role="status" class="muted"></p>
  <div id="ov-empty" class="ov-empty" hidden><h2>보유 자산부터 살펴확인하십시오</h2><p>모의 현금 1,000만원으로 시작할 수 있습니다. 예시 자산을 먼저 둘러보거나 보유 종목을 직접 입력해도 가능합니다.</p><button id="ov-demo" class="primary">DEMO 자산 둘러보기</button><button id="ov-input" class="secondary">보유 자산 입력</button><button id="ov-lab" class="text-button">Strategy Lab 열기</button></div>
  <div class="ov-kpis" id="ov-kpis"></div>
  <div class="ov-grid">
    <article class="panel ov-holdings"><div class="panel-head"><div><h2>보유 종목</h2><p class="muted">종목을 누르면 관련 기사와 원칙을 함께 볼 수 있습니다.</p></div><button id="ov-manage" class="text-button">자산 입력</button></div><div class="table-wrap"><table><thead><tr><th>종목</th><th>현재가 / 일간 등락</th><th>평가액 / 비중</th><th>평가손익 / 수익률</th><th>일간 기여</th><th>원칙</th></tr></thead><tbody id="ov-holdings"></tbody></table></div></article>
    <article class="panel"><h2>자산 구성</h2><div id="ov-allocation"></div><p class="muted">현금을 포함한 총자산 기준 비중</p><button id="ov-sim" class="secondary">추가 투자 계산</button></article>
    <article class="panel ov-briefing"><div class="panel-head"><div><h2>내 종목 브리핑</h2><p class="muted">시세 변화와 관련 검색 기사</p></div><button id="ov-news-refresh" class="text-button">기사 갱신</button></div><div id="ov-briefing"></div></article>
    <article class="panel"><div class="panel-head"><h2>투자 원칙 점검</h2><button id="ov-principles-edit" class="text-button">기준 설정</button></div><div id="ov-rules"></div><p class="muted">매매 신호와 별도 평가. 평가 가능한 규칙을 동일 가중치로 계산하며, 임박은 기준 이내로 집계합니다.</p></article>
  </div>
  <details class="panel ov-editor" id="ov-editor"><summary>보유 자산 직접 입력</summary><p class="muted">조회용 입력입니다. 모의 잔고·실제 계좌를 바꾸지 않아요. 국내 원화 주식만 지원합니다.</p><form id="ov-position-form"><div class="ov-form"><label>종목 이름<input id="ov-symbol" value="삼성전자" list="symbols" required></label><label>보유 수량<input id="ov-qty" type="number" min="1" step="1" value="10" required></label><label>평균 매입가 (원)<input id="ov-cost" type="number" min="1" value="70000" required></label><label>보유 현금 (원)<input id="ov-cash" type="number" min="0" value="0" required></label></div><button class="primary" type="submit">자산 저장·시세 조회</button><p id="ov-input-status" role="status"></p></form><div id="ov-manual-list"></div></details>
  <details class="panel ov-editor" id="ov-principles"><summary>내 자산 배분 원칙</summary><p>종목별 최대 비중과 남겨둘 현금 비중을 정하세요. 매매 전략의 진입 비중과 별도인 보유 자산 기준입니다.</p><form id="ov-principle-form"><div class="ov-form"><label>종목별 최대 비중 (%)<input id="ov-max" type="number" min="1" max="100" step=".1" value="25" required></label><label>최소 현금 비중 (%)<input id="ov-min" type="number" min="0" max="100" step=".1" value="10" required></label></div><button class="primary" type="submit">이 원칙 승인</button><p id="ov-principle-status" role="status"></p></form></details>
  <article class="panel"><h2>검증한 기준으로 이어가기</h2><p id="ov-strategy-summary"></p><div class="ov-actions"><button data-ov-go="strategy" class="secondary">Strategy Lab</button><button data-ov-go="comparison" class="secondary">최근 3개월 비교</button><button data-ov-go="assets" class="secondary">모의 판단·주문</button><button data-ov-go="evidence" class="text-button">판단 기록</button></div></article>`;
$('#home').prepend(root);
const allocation=root.querySelector('.ov-grid>.panel:nth-child(2)'),briefing=root.querySelector('.ov-briefing');root.querySelector('.ov-holdings').after(briefing);
$('.flow-wrap').hidden=true;
const navigation=$('.sidebar nav');
for(const page of ['home','assets','strategy','comparison','news','evidence']){
  const button=$(`[data-view="${page}"]`);button.classList.remove('flow-step');button.innerHTML={home:'자산 현황',assets:'모의 운용',strategy:'Strategy Lab',comparison:'3개월 비교',news:'뉴스',evidence:'판단 기록'}[page];navigation.append(button);
}
const simNav=document.createElement('button');simNav.className='nav-button';simNav.dataset.view='simulation';simNav.textContent='시뮬레이션';navigation.insertBefore(simNav,$('[data-view="news"]'));
$('.sidebar').classList.add('overview-nav');
$('#strategy h1').textContent='Strategy Lab';$('#strategy .page-head p').textContent='내 투자 조건을 정리하고, 승인한 규칙을 과거 데이터로 확인하세요.';
const labCompare=document.createElement('button');labCompare.className='secondary';labCompare.textContent='3개월 비교 열기';labCompare.onclick=()=>navigate('comparison');$('#strategy .page-head').append(labCompare);
const simulation=document.createElement('section');simulation.className='view';simulation.dataset.page='simulation';simulation.id='simulation';simulation.innerHTML=`<div class="page-head"><div><h1>추가 투자 계산</h1><p>수익률을 가정하고 납입 원금과 운용 결과를 나눠 확인하세요.</p></div></div><div class="sim-layout"><article class="panel"><h2>계산 조건</h2><p id="sim-context" class="muted"></p><form id="sim-form"><div class="ov-form"><label>시작 자산 (원)<input id="sim-initial" type="number" min="0" value="10000000" required></label><label>지금 추가할 금액 (원)<input id="sim-once" type="number" min="0" value="0" required></label><label>매월 적립액 (원)<input id="sim-monthly" type="number" min="0" value="500000" required></label><label>기간 (개월)<input id="sim-months" type="number" min="1" max="600" value="120" required></label><label>가정 연 수익률 (%)<input id="sim-rate" type="number" min="-99" max="100" step=".1" value="0" required></label><label>연간 운용 비용 (%)<input id="sim-fee" type="number" min="0" max="20" step=".1" value="0" required></label></div><button class="primary" type="submit">가정별 비교</button></form><p class="muted">월말 납입 · 수익률과 비용을 월 복리로 환산 · 세금·물가 미반영 · 가격·수익 예측 아님</p></article><article class="panel"><h2>가정에 따른 자산 변화</h2><div id="sim-result"></div><button id="sim-save" class="secondary" disabled>계산 조건과 결과 저장</button><p id="sim-status" role="status"></p></article></div><article class="panel"><h2>저장한 시뮬레이션</h2><div id="sim-history"></div></article>`;document.querySelector('main').append(simulation);
const audit=document.createElement('button');audit.className='secondary';audit.textContent='원칙·검토 JSON 저장';audit.onclick=()=>{const o=get(),blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),principleVersions:o.principleVersions,reviews:o.reviews,simulationRuns:o.simulationRuns},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='teamquant-portfolio-review.json';a.click();URL.revokeObjectURL(url);};$('#evidence .page-head').append(audit);
const detail=document.createElement('dialog');detail.id='ov-detail';detail.innerHTML='<div class="panel-head"><h2 id="ov-detail-title"></h2><button id="ov-detail-close" class="text-button">닫기</button></div><div id="ov-detail-body"></div>';document.body.append(detail);$('#ov-detail-close').onclick=()=>detail.close();
let currentMetrics,selectedSymbol=null,newsBusy=false,newsEpoch=0,simResult=null;
function render(){
  if(!key())return;const o=get(),p=portfolio();currentMetrics=metrics();const m=currentMetrics,r=evaluatePrinciples(m,o.principles);
  $('#ov-mode').value=o.mode;
  $('#ov-source').textContent=o.mode==='account'?`${liveAccount.label} · 금융사 조회 ${liveAccount.fetchedAt} · 현재 화면에만 보관 · 주문 없음`:o.mode==='demo'?'DEMO · 합성 보유 수량·매입가·가격. 실제 계좌나 투자 성과가 아닙니다.':o.mode==='manual'?'직접 입력한 수량·매입가 + 조회 시세 · 계좌 미연결':'브라우저에 저장한 모의 잔고 · 실제 계좌와 별도';
  $('#ov-empty').hidden=p.positions.length>0;$('#ov-empty p').textContent=o.mode==='paper'?`현재 모의 현금은 ${money(m.cash)}입니다. 예시 자산을 둘러보거나 보유 종목을 직접 입력해도 가능합니다.`:'보유 수량·평균 매입가·현금을 입력하면 조회 시세와 함께 손익을 계산합니다.';
  $('#ov-kpis').innerHTML=[['총자산',money(m.total),'현금 '+money(m.cash)],['보유 자산 평가손익',money(m.pnl),m.returnPct===null?'보유 원가 기준':pct(m.returnPct)+' · 보유 원가 기준'],['최근 거래일 가격변화 기여',money(m.dailyPnl),'현재 수량 × 전일 대비 가격 차이'],['원칙 충족',r.score===null?'미설정':r.score.toFixed(0)+'%',r.measurable+'개 평가 가능 · 동일 가중치']].map(([a,b,c])=>`<article><span>${a}</span><strong>${b}</strong><small>${c}</small></article>`).join('');
  $('#ov-holdings').innerHTML=m.positions.map(x=>{const rule=r.evaluations.find(e=>e.symbol===x.symbol);return `<tr><td><button class="stock-link" data-stock="${esc(x.symbol)}">${esc(x.name)}</button><small>${x.quantity}주 · 평단 ${money(x.avgCost)}</small></td><td>${money(x.price)}<small>${pct(x.dailyPct)}</small><small>${esc(x.asOf||'자료 없음')}</small></td><td>${money(x.value)}<small>${x.weightPct===null?'—':x.weightPct.toFixed(1)+'%'}</small></td><td>${money(x.pnl)}<small>${pct(x.returnPct)}</small></td><td>${money(x.dailyPnl)}</td><td>${rule?.status||'미설정'}</td></tr>`;}).join('')||'<tr><td colspan="6" class="empty">보유 종목이 없습니다. 자산을 입력하거나 DEMO로 둘러확인하십시오.</td></tr>';
  $('#ov-allocation').innerHTML=m.total>0?[...m.positions.map(x=>[x.name,x.weightPct]),['현금',m.cashPct]].map(([name,value])=>`<div class="allocation-row"><span>${esc(name)}</span><b>${value.toFixed(1)}%</b><div><i style="width:${Math.min(100,value)}%"></i></div></div>`).join(''):'<p class="muted">모든 종목의 가격을 확인하면 비중을 표시합니다.</p>';
  $('#ov-rules').innerHTML=r.evaluations.length?r.evaluations.map(e=>`<div class="rule-row"><b>${esc(e.label)} · ${e.status}</b><p>${e.actual===null?'가격 자료 부족':`현재 ${e.actual.toFixed(2)}% / ${e.direction==='max'?'최대':'최소'} ${e.threshold}%${e.gap>0?' · '+e.gap.toFixed(2)+'%p '+(e.direction==='max'?'초과':'부족'):''}`}</p>${e.status==='위반'&&e.symbol?`<button class="text-button" data-review="${esc(e.symbol)}">대응 선택지 보기</button>`:''}</div>`).join('')+'<small>원칙 버전 '+esc(o.principles.id)+'</small>':'<p>자산 배분 원칙이 아직 없습니다. 종목별 최대 비중과 최소 현금을 정해확인하십시오.</p>';
  $('#ov-strategy-summary').textContent=state().approved?state().approved.definition.name+' · '+state().approved.definition.entryRule:'아직 승인한 매매 전략이 없습니다. 자산을 먼저 살펴본 뒤 Strategy Lab에서 정해도 가능합니다.';
  $('#ov-manual-list').innerHTML=(o.manualPortfolio?.positions||[]).map(x=>`<p>${esc(x.name)} · ${x.quantity}주 <button class="text-button" data-remove="${esc(x.symbol)}">삭제</button></p>`).join('');
  $('#sim-history').innerHTML=(o.simulationRuns||[]).slice().reverse().slice(0,10).map(x=>`<p>${new Date(x.savedAt).toLocaleString('ko-KR')} · ${x.assumptions.months}개월 · 월 ${money(x.assumptions.monthly)} · 가정 ${x.assumptions.annualRate}% → ${money(x.value)}</p>`).join('')||'<p class="muted">저장한 계산이 없습니다.</p>';
  renderBriefing();if(selectedSymbol&&detail.open)renderDetail(selectedSymbol);
}
function renderBriefing(){
  const o=get(),m=currentMetrics;if(!m)return;
  const movers=m.positions.filter(p=>p.dailyPnl!==null).sort((a,b)=>Math.abs(b.dailyPnl)-Math.abs(a.dailyPnl));
  $('#ov-briefing').innerHTML=(movers.length?movers:m.positions).slice(0,3).map((p,index)=>{
    const cache=o.newsCache?.[p.symbol],item=cache?relevantArticles(p,cache.items||[])[0]:null;
    return `<div class="brief-row"><button class="stock-link" data-stock="${esc(p.symbol)}">${esc(p.name)}</button><p>${o.mode==='demo'?'합성 DEMO 가격 변화':p.asOf?esc(p.asOf)+' 일봉 기준':'시세 확인 전'} · ${pct(p.dailyPct)} · 현재 보유 수량 기준 ${money(p.dailyPnl)}</p>${item?`<a href="${safeUrl(item.link)}" target="_blank" rel="noopener noreferrer">${esc(item.title)}</a><p>${index===0?esc(item.description.slice(0,140))+(item.description.length>140?'…':''):''}</p><small>${esc(item.sourceHost)} · 발행 ${esc(item.publishedAt||'시각 미상')} · 수집 ${esc(cache.fetchedAt)}</small>`:`<p class="muted">${esc(cache?.error|| (cache?'확인된 관련 보도 없음':'관련 보도 조회 전'))}</p>`}${index===0?`<p class="muted">${o.mode==='demo'?'실제 검색 기사는 DEMO 가격과 무관합니다. ':''}키워드 관련 기사이며 가격 변화의 원인으로 확인한 내용은 아닙니다.</p>`:''}</div>`;
  }).join('')||'<p>보유 종목을 추가하면 가격 변화와 관련 보도를 함께 보여드려요.</p>';
}
function safeUrl(url){try{const u=new URL(url);return ['http:','https:'].includes(u.protocol)?esc(u.href):'#';}catch{return '#';}}
async function refreshQuotes(){
  const user=key(),o=get(),positions=portfolio().positions;
  if(o.mode==='account'){document.querySelector('[data-connect-account]').click();return;}
  if(o.mode==='demo'){$('#ov-status').textContent='DEMO는 고정 예시 가격을 사용합니다. 실제 시세는 직접 입력한 자산에서 조회하세요.';return;}
  if(!positions.length){$('#ov-status').textContent='먼저 종목을 입력하거나 모의 자산을 보유해 주세요.';return;}
  $('#ov-refresh').disabled=true;$('#ov-status').textContent='종목별 일봉 시세 확인 중…';
  const result=await Promise.allSettled(positions.map(async p=>{
    const res=await fetch('/api/market?'+new URLSearchParams({symbol:p.symbol,range:'3mo'}));const data=await res.json();if(!res.ok)throw new Error(p.name+': '+(data.error||'조회 실패'));
    if(data.currency!=='KRW')throw new Error(p.name+': 원화 자료만 지원');
    const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul'}).format(new Date()),hour=Number(new Intl.DateTimeFormat('en',{timeZone:'Asia/Seoul',hour:'numeric',hourCycle:'h23'}).format(new Date()));
    const candles=data.candles.filter(c=>hour>=16||c.date!==today),last=candles.at(-1),prev=candles.at(-2);if(!last||!prev)throw new Error(p.name+': 가격 자료 부족');
    return [p.symbol,{price:last.close,prevClose:prev.close,asOf:last.date,fetchedAt:data.fetchedAt,source:data.source}];
  }));
  $('#ov-refresh').disabled=false;if(user!==key()||get().mode!==o.mode)return;
  const quotes={...get().quotes};for(const r of result)if(r.status==='fulfilled')quotes[r.value[0]]=r.value[1];save({quotes});render();
  $('#ov-status').textContent=result.some(r=>r.status==='rejected')?result.filter(r=>r.status==='rejected').map(r=>r.reason.message).join(' / ')+' · 실패한 종목은 이전 스냅샷 유지':`조회 완료 · ${new Date().toLocaleString('ko-KR')} · Yahoo 비공식 지연 일봉. 거래소 실시간 가격이 아닙니다.`;
  fetchBriefing();
}
async function fetchBriefing(force=false){
  if(!key()||newsBusy)return;const owner=key(),epoch=++newsEpoch,o=get(),positions=portfolio().positions.slice(0,6);
  const needed=positions.filter(p=>force||!o.newsCache?.[p.symbol]||Date.now()-Date.parse(o.newsCache[p.symbol].fetchedAt)>600000);
  if(!needed.length)return;newsBusy=true;$('#ov-news-refresh').disabled=true;
  try{const results=await Promise.all(needed.map(async p=>{try{const r=await fetch('/api/news?'+new URLSearchParams({query:briefingQuery(p),sort:'date'}));const d=await r.json();if(!r.ok)throw new Error(d.error||'뉴스 조회 실패');return [p.symbol,{...d,items:relevantArticles(p,d.items).slice(0,5)}];}catch(e){return [p.symbol,{error:e.message,fetchedAt:new Date().toISOString(),items:[]}];}}));
    if(owner!==key()||epoch!==newsEpoch)return;save({newsCache:{...get().newsCache,...Object.fromEntries(results)}});renderBriefing();if(detail.open)renderDetail(selectedSymbol);
  }finally{newsBusy=false;$('#ov-news-refresh').disabled=false;}
}
function openEditor(){navigate('home');get().manualPortfolio&&($('#ov-cash').value=get().manualPortfolio.cash);$('#ov-editor').open=true;$('#ov-editor').scrollIntoView({behavior:'smooth'});}
function switchMode(mode){save({mode});selectedSymbol=null;render();fetchBriefing();}
$('#ov-mode').onchange=e=>switchMode(e.target.value);$('#ov-demo').onclick=()=>switchMode('demo');$('#ov-input').onclick=openEditor;$('#ov-manage').onclick=openEditor;$('#ov-lab').onclick=()=>navigate('strategy');$('#ov-refresh').onclick=refreshQuotes;$('#ov-news-refresh').onclick=()=>fetchBriefing(true);
$('#ov-principles-edit').onclick=()=>{const o=get();$('#ov-max').value=o.principles?.maxPositionPct??25;$('#ov-min').value=o.principles?.minCashPct??10;$('#ov-principles').open=true;$('#ov-principles').scrollIntoView({behavior:'smooth'});};
$('#ov-principle-form').onsubmit=e=>{e.preventDefault();const principles={id:'P-'+Date.now(),approvedAt:new Date().toISOString(),maxPositionPct:Number($('#ov-max').value),minCashPct:Number($('#ov-min').value)};save({principles,principleVersions:[...get().principleVersions,principles]});$('#ov-principle-status').textContent='원칙을 승인했습니다. 자산 비중 기준으로 다시 계산했습니다.';render();};
$('#ov-position-form').onsubmit=async e=>{e.preventDefault();const owner=key();try{const symbol=await resolveStockInput($('#ov-symbol').value);if(owner!==key())return;const qty=Number($('#ov-qty').value),cost=Number($('#ov-cost').value),cash=Number($('#ov-cash').value);if(!Number.isInteger(qty)||qty<=0||cost<=0||!Number.isFinite(cost)||cash<0||!Number.isFinite(cash))throw new Error('입력값을 확인하세요.');const p=get().manualPortfolio||{cash:0,positions:[]};p.positions=p.positions.filter(x=>x.symbol!==symbol);p.positions.push({symbol,name:stockName(symbol),quantity:qty,avgCost:cost});p.cash=cash;save({manualPortfolio:p,mode:'manual'});render();$('#ov-input-status').textContent='자산 저장 완료. 현재 시세를 확인하고 있습니다.';await refreshQuotes();}catch(err){$('#ov-input-status').textContent=err.message;}};
root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.stock||b.dataset.review){selectedSymbol=b.dataset.stock||b.dataset.review;renderDetail(selectedSymbol);detail.showModal();}if(b.dataset.ovGo)navigate(b.dataset.ovGo);if(b.dataset.remove){const p=get().manualPortfolio;p.positions=p.positions.filter(x=>x.symbol!==b.dataset.remove);save({manualPortfolio:p});render();}});
function renderDetail(symbol){
  const draftChoice=detail.open?$('#review-choice')?.value:null,draftReason=detail.open?$('#review-reason')?.value:null;
  const o=get(),m=metrics(),p=m.positions.find(x=>x.symbol===symbol);if(!p)return;const r=evaluatePrinciples(m,o.principles),rule=r.evaluations.find(x=>x.symbol===symbol);let options=null;if(rule&&rule.actual!==null)options=rebalanceOptions(m,symbol,rule.threshold);
  $('#ov-detail-title').textContent=p.name;
  $('#ov-detail-body').innerHTML=`<p>${money(p.price)} · ${pct(p.dailyPct)} · ${esc(p.asOf||'가격 조회 전')} ${o.mode==='demo'?' · DEMO':''}</p><p>비중 ${p.weightPct?.toFixed(2)??'—'}% · 평가손익 ${money(p.pnl)}</p><h3>원칙과 대응 선택지</h3><p>${rule?`${rule.status} · 최대 ${rule.threshold}% / 현재 ${rule.actual?.toFixed(2)??'—'}%`:'자산 배분 원칙을 먼저 승인하세요.'}</p>${options?`<div class="scenario-option"><b>현재 자산 유지</b><p>비중 ${options.beforeWeightPct.toFixed(2)}% 유지. 가격이 움직이면 비중도 달라져요.</p></div><div class="scenario-option"><b>최대 비중 이내로 조정</b><p>${options.quantity}주 감소 가정 · 비용 ${money(options.fees)} · 조정 후 비중 ${options.afterWeightPct?.toFixed(2)??'—'}% · 현금 ${money(options.afterCash)}</p><small>현재 조회 가격 고정 · 비용 ${options.feePct}% · 세금 미포함 · 주문 없음</small></div><div class="scenario-option"><b>매도 없이 현금 추가</b><p>${money(options.additionalCash)}을 더하면 해당 종목 비중을 ${rule.threshold}% 이내로 낮출 수 있습니다. 다른 원칙 충족 여부는 별도입니다.</p></div><label>검토한 선택<select id="review-choice"><option>현재 자산 유지</option><option>비중 조정 검토</option><option>현금 추가 검토</option><option>판단 보류</option></select></label><label>내 판단 이유<input id="review-reason" maxlength="300" placeholder="어떤 근거를 확인했나요?"></label><button id="review-save" class="primary">선택과 근거 기록</button><p id="review-status" role="status"></p>`:''}<h3>관련 기사</h3>${relevantArticles(p,o.newsCache?.[symbol]?.items||[]).slice(0,3).map(x=>`<p><a href="${safeUrl(x.link)}" target="_blank" rel="noopener noreferrer">${esc(x.title)}</a><br><small>${esc(x.sourceHost)} · ${esc(x.publishedAt)}</small></p>`).join('')||'<p>확인된 관련 보도 없음</p>'}<p class="muted">기사와 가격의 인과관계는 확인하지 않았습니다. 위 선택지는 현재 가격에 대한 계산이며 매매 추천이나 자동 주문이 아닙니다.</p>`;
  if(draftChoice&&$('#review-choice'))$('#review-choice').value=draftChoice;if(draftReason&&$('#review-reason'))$('#review-reason').value=draftReason;
  if(options)$('#review-save').onclick=()=>{if(o.mode==='account'){$('#review-status').textContent='실제 계좌의 수량·잔고는 저장하지 않아요. 현재 화면에서만 검토해 주세요.';return;}const reason=$('#review-reason').value.trim();if(!reason){$('#review-status').textContent='판단 이유를 입력하십시오.';return;}const review={id:'R-'+Date.now(),symbol,mode:o.mode,action:$('#review-choice').value,reason,principle:o.principles,metrics:m,options,articleRefs:o.newsCache?.[symbol]?.items||[],createdAt:new Date().toISOString()};save({reviews:[...get().reviews,review]});window.dispatchEvent(new CustomEvent('teamquant:review',{detail:review}));$('#review-status').textContent='판단 기록에 저장했습니다. 주문은 실행하지 않았습니다.';};
}
function openSim(){const m=metrics();$('#sim-initial').value=Math.round(m.total??0);$('#sim-context').textContent=$('#ov-source').textContent;navigate('simulation');calculateSim();}
$('#ov-sim').onclick=openSim;
function chart(series){return performanceChart(['value','principal'].map(key=>series.map((x,i)=>({date:x.month+'개월',value:x[key]}))),['수익률 가정 적용 자산','납입 원금'],{normalized:false,unit:'원',title:'납입 원금과 가정 자산'});}
function allocationImpact(args){
  const m=metrics();if(!m.total||Math.abs(args.initial-m.total)>1)return '<p class="muted">시작 자산을 바꿨으므로 현재 포트폴리오의 비중 비교는 생략했습니다.</p>';
  const total=m.total+args.once;
  return `<details><summary>일회 납입 직후 자산 비중</summary><p class="muted">추가금 전액을 현금으로 보유한 순간의 계산. 이후 종목 매수·가격변화·월 적립 배분은 가정하지 않아요.</p><table><thead><tr><th>자산</th><th>현재</th><th>납입 직후</th></tr></thead><tbody>${[...m.positions.map(p=>[p.name,p.value]),['현금',m.cash]].map(([name,value])=>`<tr><td>${esc(name)}</td><td>${(value/m.total*100).toFixed(2)}%</td><td>${((value+(name==='현금'?args.once:0))/total*100).toFixed(2)}%</td></tr>`).join('')}</tbody></table></details>`;
}
function calculateSim(){try{const args={initial:Number($('#sim-initial').value),once:Number($('#sim-once').value),monthly:Number($('#sim-monthly').value),months:Number($('#sim-months').value),annualRate:Number($('#sim-rate').value),annualFee:Number($('#sim-fee').value)};simResult=simulateContributions(args);const other=[args.annualRate-3,args.annualRate,args.annualRate+3].filter(x=>x>-100&&x<=100).map(annualRate=>simulateContributions({...args,annualRate}));$('#sim-result').innerHTML=`<div class="sim-total"><small>${args.months}개월 후 · 가정 결과</small><strong>${money(simResult.value)}</strong><p>기준 원금 ${money(simResult.principal)} · 가정 운용 손익 ${money(simResult.gain)}</p></div>${chart(simResult.series)}${allocationImpact(args)}<table><thead><tr><th>가정 연 수익률</th><th>가정 자산</th><th>원금 대비</th></tr></thead><tbody>${other.map(r=>`<tr><td>${r.assumptions.annualRate.toFixed(1)}%</td><td>${money(r.value)}</td><td>${money(r.gain)}</td></tr>`).join('')}</tbody></table><p class="muted">±3%p는 비교용 가정이며 확률 구간이 아닙니다. 시작 자산은 이번 계산의 기준 원금으로 취급합니다.</p>`;wireCharts($('#sim-result'));$('#sim-save').disabled=false;$('#sim-status').textContent='';}catch(e){simResult=null;$('#sim-save').disabled=true;$('#sim-status').textContent=e.message;}}
$('#sim-form').onsubmit=e=>{e.preventDefault();calculateSim();};$('#sim-form').addEventListener('input',()=>{simResult=null;$('#sim-save').disabled=true;$('#sim-status').textContent='조건이 변경되었습니다. 다시 계산해 주세요.';});
$('#sim-save').onclick=()=>{if(get().mode==='account'){$('#sim-status').textContent='실제 계좌 금액을 포함한 계산은 현재 화면에서만 확인하십시오. 저장하지 않았습니다.';return;}if(!simResult)return;save({simulationRuns:[...get().simulationRuns,{...simResult,savedAt:new Date().toISOString(),mode:get().mode}].slice(-30)});render();$('#sim-status').textContent='가정과 월별 결과를 저장했습니다.';};
window.addEventListener('teamquant:state',()=>{render();fetchBriefing();});window.addEventListener('teamquant:page',()=>{if($('.view.active')?.dataset.page==='home'){render();fetchBriefing();}});
render();

window.addEventListener('teamquant:account-snapshot',event=>{
 const d=event.detail;
 if(!d.configured||!Array.isArray(d.holdings))return;
 const positions=d.holdings.map(h=>({symbol:h.symbol,name:h.name,quantity:h.quantity,avgCost:h.averagePrice}));
 liveAccount={owner:key(),label:d.mode==='prod'?'한국투자 실제 계좌 · 조회 전용':'한국투자 모의계좌 · 조회 전용',fetchedAt:d.fetchedAt,portfolio:{cash:d.summary.cash,positions},quotes:Object.fromEntries(d.holdings.map(h=>[h.symbol,{price:h.currentPrice,prevClose:null,asOf:d.fetchedAt,source:'한국투자증권 잔고 조회'}]))};
 if(!$('#ov-mode option[value="account"]')){const option=document.createElement('option');option.value='account';option.textContent='한국투자 조회 잔고';$('#ov-mode').append(option);}
 save({mode:'account'});render();fetchBriefing();$('#ov-status').textContent='보유 국내 주식과 현금 기준. 펀드·해외자산·미수·정산항목은 포함되지 않아 금융사 총평가액과 다를 수 있습니다. 전일 가격 자료가 없어 일간 손익은 표시하지 않아요.';
});
window.addEventListener('teamquant:account-disconnect',()=>{liveAccount=null;save({mode:'paper'});$('#ov-mode option[value="account"]')?.remove();render();$('#ov-status').textContent='조회 계좌의 현재 화면 데이터를 삭제했습니다.';});
