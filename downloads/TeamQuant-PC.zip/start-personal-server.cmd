@echo off
cd /d "%~dp0"
node dev-server.mjs
pause
